"""
05_strategy_insights.py
-------------------------
Analyses stop-order distance distributions and time-of-day profitability
patterns to surface actionable strategy improvements.
"""

import numpy as np
import pandas as pd
import json

df = pd.read_csv("/home/claude/project/data/trades_enriched.csv", parse_dates=["open_time", "close_time"])

insights = {}

# --- 1. Stop distance buckets (forex only, pip-denominated, comparable) ---
fx = df[df.market_class == "forex"].copy()
bins = [0, 8, 15, 25, 1000]
labels = ["<8 pips (very tight)", "8-15 pips", "15-25 pips", ">25 pips"]
fx["stop_bucket"] = pd.cut(fx["stop_distance_pips_or_pts"], bins=bins, labels=labels)

stop_perf = fx.groupby("stop_bucket", observed=True).agg(
    n_trades=("net_profit", "size"),
    win_rate_pct=("is_win", lambda x: round(x.mean() * 100, 1)),
    avg_net_profit=("net_profit", lambda x: round(x.mean(), 2)),
    total_net_profit=("net_profit", lambda x: round(x.sum(), 2)),
).reset_index()
insights["stop_distance_buckets_fx"] = stop_perf.to_dict(orient="records")

# --- 2. Time-of-day / session profitability --------------------------------
session_perf = df.groupby("session").agg(
    n_trades=("net_profit", "size"),
    win_rate_pct=("is_win", lambda x: round(x.mean() * 100, 1)),
    avg_net_profit=("net_profit", lambda x: round(x.mean(), 2)),
    total_net_profit=("net_profit", lambda x: round(x.sum(), 2)),
).reset_index().sort_values("total_net_profit", ascending=False)
insights["session_profitability"] = session_perf.to_dict(orient="records")

# Hour-level granularity for the chart
hourly_perf = df.groupby("open_hour").agg(
    n_trades=("net_profit", "size"),
    avg_net_profit=("net_profit", lambda x: round(x.mean(), 2)),
    total_net_profit=("net_profit", lambda x: round(x.sum(), 2)),
).reindex(range(24), fill_value=0).reset_index()
insights["hourly_profitability"] = hourly_perf.to_dict(orient="records")

# --- 3. Closure reason performance -----------------------------------------
closure_perf = df.groupby("closure_reason").agg(
    n_trades=("net_profit", "size"),
    win_rate_pct=("is_win", lambda x: round(x.mean() * 100, 1)),
    total_net_profit=("net_profit", lambda x: round(x.sum(), 2)),
).reset_index().sort_values("total_net_profit", ascending=False)
insights["closure_reason_performance"] = closure_perf.to_dict(orient="records")

# --- 4. Risk:reward planned vs outcome -------------------------------------
df["rr_bucket"] = pd.cut(df["risk_reward_planned"], bins=[0, 1, 1.5, 2, 100],
                          labels=["<1:1", "1-1.5:1", "1.5-2:1", ">2:1"])
rr_perf = df.groupby("rr_bucket", observed=True).agg(
    n_trades=("net_profit", "size"),
    win_rate_pct=("is_win", lambda x: round(x.mean() * 100, 1)),
    total_net_profit=("net_profit", lambda x: round(x.sum(), 2)),
).reset_index()
insights["risk_reward_buckets"] = rr_perf.to_dict(orient="records")

with open("/home/claude/project/data/strategy_insights.json", "w") as f:
    json.dump(insights, f, indent=2, default=str)

print("=== STOP DISTANCE BUCKETS (FX) ===")
print(stop_perf.to_string(index=False))
print("\n=== SESSION PROFITABILITY ===")
print(session_perf.to_string(index=False))
print("\n=== CLOSURE REASON PERFORMANCE ===")
print(closure_perf.to_string(index=False))
print("\n=== RISK:REWARD BUCKETS ===")
print(rr_perf.to_string(index=False))
