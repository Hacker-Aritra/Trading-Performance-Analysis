"""
06_generate_charts.py
-----------------------
Generates all charts used in the final report.
"""

import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "axes.edgecolor": "#444444",
    "axes.labelcolor": "#222222",
    "text.color": "#222222",
    "xtick.color": "#444444",
    "ytick.color": "#444444",
    "axes.grid": True,
    "grid.alpha": 0.25,
    "grid.linestyle": "-",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
})

NAVY = "#1f3a5f"
TEAL = "#2a9d8f"
GOLD = "#e9b44c"
RED = "#c0392b"
GREY = "#7f8c8d"

OUT = "/home/claude/project/charts"

df = pd.read_csv("/home/claude/project/data/trades_enriched.csv", parse_dates=["open_time", "close_time"])
with open("/home/claude/project/data/monte_carlo_results.json") as f:
    mc = json.load(f)
with open("/home/claude/project/data/strategy_insights.json") as f:
    insights = json.load(f)
with open("/home/claude/project/data/performance_metrics.json") as f:
    perf = json.load(f)

mc_sample_paths = np.load("/home/claude/project/data/mc_sample_paths.npy")
mc_final_pnl = np.load("/home/claude/project/data/mc_final_pnl.npy")

# ---------------------------------------------------------------- 1. Equity curve + drawdown
fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True, height_ratios=[2.2, 1])
axes[0].plot(df["trade_sequence"], df["cumulative_pnl"], color=NAVY, linewidth=2)
axes[0].fill_between(df["trade_sequence"], df["cumulative_pnl"], 0,
                      where=(df["cumulative_pnl"] >= 0), color=TEAL, alpha=0.15)
axes[0].fill_between(df["trade_sequence"], df["cumulative_pnl"], 0,
                      where=(df["cumulative_pnl"] < 0), color=RED, alpha=0.12)
axes[0].axhline(0, color="#999999", linewidth=0.8)
axes[0].set_ylabel("Cumulative Net P&L ($)")
axes[0].set_title("Equity Curve — 92 Live Trades", fontsize=13, fontweight="bold", color=NAVY)
axes[0].yaxis.set_major_formatter(mticker.StrMethodFormatter("${x:,.0f}"))

axes[1].fill_between(df["trade_sequence"], df["drawdown"], 0, color=RED, alpha=0.5)
axes[1].plot(df["trade_sequence"], df["drawdown"], color=RED, linewidth=1)
axes[1].set_ylabel("Drawdown ($)")
axes[1].set_xlabel("Trade Sequence")
axes[1].yaxis.set_major_formatter(mticker.StrMethodFormatter("${x:,.0f}"))

plt.tight_layout()
plt.savefig(f"{OUT}/01_equity_curve_drawdown.png", dpi=180)
plt.close()

# ---------------------------------------------------------------- 2. Monte Carlo fan chart
fig, ax = plt.subplots(figsize=(10, 6))
x = np.arange(1, mc_sample_paths.shape[1] + 1)
for i in range(mc_sample_paths.shape[0]):
    ax.plot(x, mc_sample_paths[i], color=NAVY, alpha=0.035, linewidth=0.7)

# Percentile bands across all 100k sims - recompute from saved final + need full path percentiles
# Use the 300-path sample's own percentiles per step as a representative fan
p10 = np.percentile(mc_sample_paths, 10, axis=0)
p50 = np.percentile(mc_sample_paths, 50, axis=0)
p90 = np.percentile(mc_sample_paths, 90, axis=0)
ax.plot(x, p50, color=GOLD, linewidth=2.4, label="Median path")
ax.plot(x, p10, color=RED, linewidth=1.6, linestyle="--", label="10th percentile")
ax.plot(x, p90, color=TEAL, linewidth=1.6, linestyle="--", label="90th percentile")
ax.axhline(0, color="#999999", linewidth=0.8)
ax.set_xlabel("Future Trade Number")
ax.set_ylabel("Simulated Cumulative P&L ($)")
ax.set_title("Monte Carlo Simulation — 100,000 Runs of Next 100 Trades", fontsize=13, fontweight="bold", color=NAVY)
ax.yaxis.set_major_formatter(mticker.StrMethodFormatter("${x:,.0f}"))
ax.legend(loc="upper left", frameon=False)
plt.tight_layout()
plt.savefig(f"{OUT}/02_monte_carlo_fan_chart.png", dpi=180)
plt.close()

# ---------------------------------------------------------------- 3. Monte Carlo outcome distribution (histogram)
fig, ax = plt.subplots(figsize=(10, 5.5))
ax.hist(mc_final_pnl, bins=80, color=NAVY, alpha=0.75, edgecolor="white", linewidth=0.2)
p5 = mc["worst_case_p5"]
p95 = mc["best_case_p95"]
median = mc["median_pnl"]
ax.axvline(0, color="#444444", linewidth=1, linestyle="-")
ax.axvline(p5, color=RED, linewidth=1.6, linestyle="--", label=f"5th pct (worst-case): ${p5:,.0f}")
ax.axvline(median, color=GOLD, linewidth=1.8, label=f"Median: ${median:,.0f}")
ax.axvline(p95, color=TEAL, linewidth=1.6, linestyle="--", label=f"95th pct (best-case): ${p95:,.0f}")
ax.set_xlabel("Simulated P&L after 100 Future Trades ($)")
ax.set_ylabel("Frequency (out of 100,000 simulations)")
ax.set_title(f"Distribution of Outcomes — Probability of Profit: {mc['probability_of_profit']}%",
             fontsize=13, fontweight="bold", color=NAVY)
ax.legend(loc="upper right", frameon=False, fontsize=9)
plt.tight_layout()
plt.savefig(f"{OUT}/03_monte_carlo_distribution.png", dpi=180)
plt.close()

# ---------------------------------------------------------------- 4. Session profitability
sess = pd.DataFrame(insights["session_profitability"])
sess = sess.sort_values("total_net_profit")
fig, ax = plt.subplots(figsize=(9, 5.5))
colors = [TEAL if v >= 0 else RED for v in sess["total_net_profit"]]
bars = ax.barh(sess["session"], sess["total_net_profit"], color=colors)
xmin, xmax = sess["total_net_profit"].min(), sess["total_net_profit"].max()
span = xmax - xmin
for bar, n, wr in zip(bars, sess["n_trades"], sess["win_rate_pct"]):
    w = bar.get_width()
    if w >= 0:
        ax.text(w + span * 0.02, bar.get_y() + bar.get_height()/2,
                f"n={n}, win rate {wr}%", va="center", ha="left", fontsize=9, color="#333333")
    else:
        ax.text(-span * 0.02, bar.get_y() + bar.get_height()/2,
                f"n={n}, win rate {wr}%", va="center", ha="right", fontsize=9, color="#333333")
ax.axvline(0, color="#999999", linewidth=0.8)
ax.set_xlim(xmin - span * 0.05, xmax + span * 0.32)
ax.set_xlabel("Total Net P&L ($)")
ax.set_title("Profitability by Trading Session (Time-of-Day)", fontsize=13, fontweight="bold", color=NAVY)
ax.xaxis.set_major_formatter(mticker.StrMethodFormatter("${x:,.0f}"))
plt.tight_layout()
plt.savefig(f"{OUT}/04_session_profitability.png", dpi=180)
plt.close()

# ---------------------------------------------------------------- 5. Stop distance buckets (FX)
sd = pd.DataFrame(insights["stop_distance_buckets_fx"])
fig, ax1 = plt.subplots(figsize=(9, 5.5))
x = np.arange(len(sd))
bars = ax1.bar(x, sd["total_net_profit"], color=[TEAL if v >= 0 else RED for v in sd["total_net_profit"]], width=0.5)
ax1.set_xticks(x)
ax1.set_xticklabels(sd["stop_bucket"], rotation=0)
ax1.axhline(0, color="#999999", linewidth=0.8)
ax1.set_ylabel("Total Net P&L ($)")
ax1.yaxis.set_major_formatter(mticker.StrMethodFormatter("${x:,.0f}"))
ax2 = ax1.twinx()
ax2.plot(x, sd["win_rate_pct"], color=GOLD, marker="o", linewidth=2, markersize=7)
ax2.set_ylabel("Win Rate (%)", color="#946f00")
ax2.set_ylim(0, 105)
for i, n in enumerate(sd["n_trades"]):
    ax1.text(i, 5, f"n={n}", ha="center", fontsize=9, color="#333333")
ax1.set_title("FX Stop-Order Distance vs. Outcome", fontsize=13, fontweight="bold", color=NAVY)
plt.tight_layout()
plt.savefig(f"{OUT}/05_stop_distance_buckets.png", dpi=180)
plt.close()

# ---------------------------------------------------------------- 6. Market comparison (forex vs index)
fx_m = perf["by_market"]["forex"]
idx_m = perf["by_market"]["index"]
metrics_labels = ["Net Profit ($)", "Win Rate (%)", "Profit Factor", "Expectancy/Trade ($)"]
fx_vals = [fx_m["net_profit"], fx_m["win_rate_pct"], fx_m["profit_factor"], fx_m["expectancy_per_trade"]]
idx_vals = [idx_m["net_profit"], idx_m["win_rate_pct"], idx_m["profit_factor"], idx_m["expectancy_per_trade"]]

fig, axes = plt.subplots(1, 4, figsize=(12, 4.2))
for ax, label, fv, iv in zip(axes, metrics_labels, fx_vals, idx_vals):
    bars = ax.bar(["Forex", "Index"], [fv, iv], color=[NAVY, GOLD], width=0.55)
    ax.set_title(label, fontsize=10, fontweight="bold")
    ax.axhline(0, color="#999999", linewidth=0.7)
    for bar, v in zip(bars, [fv, iv]):
        ax.text(bar.get_x() + bar.get_width()/2, v, f"{v:,.1f}",
                ha="center", va="bottom" if v >= 0 else "top", fontsize=9)
fig.suptitle("Forex vs. Index Market Performance", fontsize=13, fontweight="bold", color=NAVY, y=1.04)
plt.tight_layout()
plt.savefig(f"{OUT}/06_market_comparison.png", dpi=180)
plt.close()

# ---------------------------------------------------------------- 7. Closure reason performance
cr = pd.DataFrame(insights["closure_reason_performance"]).sort_values("total_net_profit")
fig, ax = plt.subplots(figsize=(9, 5.5))
colors = [TEAL if v >= 0 else RED for v in cr["total_net_profit"]]
bars = ax.barh(cr["closure_reason"].str.replace("_", " ").str.title(), cr["total_net_profit"], color=colors)
xmin2, xmax2 = cr["total_net_profit"].min(), cr["total_net_profit"].max()
span2 = xmax2 - xmin2
for bar, n in zip(bars, cr["n_trades"]):
    w = bar.get_width()
    if w >= 0:
        ax.text(w + span2 * 0.02, bar.get_y() + bar.get_height()/2,
                f"n={n}", va="center", ha="left", fontsize=9)
    else:
        ax.text(-span2 * 0.02, bar.get_y() + bar.get_height()/2,
                f"n={n}", va="center", ha="right", fontsize=9)
ax.axvline(0, color="#999999", linewidth=0.8)
ax.set_xlim(xmin2 - span2 * 0.05, xmax2 + span2 * 0.15)
ax.set_xlabel("Total Net P&L ($)")
ax.set_title("Performance by Trade Closure Reason", fontsize=13, fontweight="bold", color=NAVY)
ax.xaxis.set_major_formatter(mticker.StrMethodFormatter("${x:,.0f}"))
plt.tight_layout()
plt.savefig(f"{OUT}/07_closure_reason_performance.png", dpi=180)
plt.close()

print("All charts generated in", OUT)
import os
print(os.listdir(OUT))
