"""
03_performance_metrics.py
---------------------------
Computes profitability, drawdown, and risk-adjusted performance metrics
across the full trade sample and segmented by market (forex vs index).
"""

import numpy as np
import pandas as pd
import json

df = pd.read_csv("/home/claude/project/data/trades_enriched.csv", parse_dates=["open_time", "close_time"])

def compute_metrics(d: pd.DataFrame) -> dict:
    n = len(d)
    wins = d[d.net_profit > 0]
    losses = d[d.net_profit <= 0]

    gross_profit = wins.net_profit.sum()
    gross_loss = losses.net_profit.sum()  # negative
    net_profit = d.net_profit.sum()

    win_rate = len(wins) / n if n else np.nan
    avg_win = wins.net_profit.mean() if len(wins) else 0.0
    avg_loss = losses.net_profit.mean() if len(losses) else 0.0
    profit_factor = (gross_profit / abs(gross_loss)) if gross_loss != 0 else np.inf
    expectancy = d.net_profit.mean()
    payoff_ratio = (avg_win / abs(avg_loss)) if avg_loss != 0 else np.inf

    # Drawdown (in $ on the equity curve)
    equity = d.net_profit.cumsum()
    peak = equity.cummax()
    dd = equity - peak
    max_drawdown = dd.min()
    max_dd_pct = (dd.min() / peak.max() * 100) if peak.max() > 0 else np.nan

    # Risk-adjusted: Sharpe & Sortino using per-trade returns
    returns = d.net_profit.values
    mean_r = returns.mean()
    std_r = returns.std(ddof=1)
    downside = returns[returns < 0]
    downside_std = downside.std(ddof=1) if len(downside) > 1 else np.nan

    sharpe_per_trade = mean_r / std_r if std_r > 0 else np.nan
    sortino_per_trade = mean_r / downside_std if downside_std and downside_std > 0 else np.nan

    total_days = (d.close_time.max() - d.open_time.min()).days or 1
    trades_per_year = n / total_days * 365
    sharpe_annualised = sharpe_per_trade * np.sqrt(trades_per_year) if not np.isnan(sharpe_per_trade) else np.nan

    return {
        "n_trades": int(n),
        "net_profit": round(float(net_profit), 2),
        "gross_profit": round(float(gross_profit), 2),
        "gross_loss": round(float(gross_loss), 2),
        "win_rate_pct": round(float(win_rate) * 100, 1),
        "avg_win": round(float(avg_win), 2),
        "avg_loss": round(float(avg_loss), 2),
        "profit_factor": round(float(profit_factor), 2) if np.isfinite(profit_factor) else None,
        "payoff_ratio": round(float(payoff_ratio), 2) if np.isfinite(payoff_ratio) else None,
        "expectancy_per_trade": round(float(expectancy), 2),
        "max_drawdown_$": round(float(max_drawdown), 2),
        "max_drawdown_pct_of_peak": round(float(max_dd_pct), 1) if not np.isnan(max_dd_pct) else None,
        "sharpe_per_trade": round(float(sharpe_per_trade), 3) if not np.isnan(sharpe_per_trade) else None,
        "sharpe_annualised_approx": round(float(sharpe_annualised), 2) if not np.isnan(sharpe_annualised) else None,
        "sortino_per_trade": round(float(sortino_per_trade), 3) if not np.isnan(sortino_per_trade) else None,
        "trades_per_year_approx": round(float(trades_per_year), 1),
    }

overall = compute_metrics(df)
by_market = {m: compute_metrics(g) for m, g in df.groupby("market_class")}

results = {"overall": overall, "by_market": by_market}

with open("/home/claude/project/data/performance_metrics.json", "w") as f:
    json.dump(results, f, indent=2)

print("=== OVERALL PERFORMANCE ===")
for k, v in overall.items():
    print(f"  {k}: {v}")

print("\n=== BY MARKET ===")
for m, metrics in by_market.items():
    print(f"\n-- {m.upper()} --")
    for k, v in metrics.items():
        print(f"  {k}: {v}")
