"""
01_generate_raw_data.py
------------------------
Generates a realistic RAW broker trade-history export for a self-built
algorithmic trading system operating on Forex and Index markets.

NOTE: No live trade log was provided for this project, so this script
synthesizes 92 trades using distributions calibrated to look like a
real broker statement (MT4/MT5-style export): ticket id, symbol, side,
lot size, open/close time, open/close price, S/L, T/P, swap, commission,
profit, and a free-text "comment" field that encodes the closure reason
(the kind of messy raw field the real project would extract from).
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

rng = np.random.default_rng(42)

N_TRADES = 92

# --- Instrument universe -----------------------------------------------
FX_PAIRS = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "NZDUSD"]
INDEX_PAIRS = ["US30", "NAS100", "GER40", "SPX500"]

PIP_VALUE = {  # approx $ per pip per 1.0 lot (simplified, USD-quoted)
    "EURUSD": 10, "GBPUSD": 10, "AUDUSD": 10, "NZDUSD": 10, "USDCAD": 10,
    "USDJPY": 9.1,
}
INDEX_POINT_VALUE = {"US30": 1.0, "NAS100": 1.0, "GER40": 1.0, "SPX500": 1.0}

BASE_PRICE = {
    "EURUSD": 1.0850, "GBPUSD": 1.2650, "USDJPY": 156.30, "AUDUSD": 0.6650,
    "USDCAD": 1.3650, "NZDUSD": 0.6100,
    "US30": 38950, "NAS100": 17850, "GER40": 18250, "SPX500": 5180,
}

CLOSURE_COMMENTS = [
    "tp",            # take profit hit
    "sl",            # stop loss hit
    "[tp]",
    "[sl]",
    "manual close",
    "manual",
    "expert close",  # closed by EA logic / trailing
    "trailing stop",
    "margin call",   # rare, forced close
]

START_DATE = datetime(2025, 9, 1, 0, 0, 0)

rows = []
current_time = START_DATE

for i in range(1, N_TRADES + 1):
    is_fx = rng.random() < 0.62  # ~62% forex, ~38% index, matches "forex and index markets"
    symbol = rng.choice(FX_PAIRS) if is_fx else rng.choice(INDEX_PAIRS)
    side = rng.choice(["buy", "sell"])

    # Session gap between trades (algo runs intraday, mostly London/NY session)
    gap_hours = rng.exponential(scale=9) + 0.2
    current_time = current_time + timedelta(hours=float(gap_hours))
    # snap into a trading-hour-ish window (0-23), weighted to London/NY overlap
    hour_choice = rng.choice(
        range(24),
        p=_p if (_p := None) is None else None
    ) if False else None
    open_time = current_time

    # Lot sizing: small retail account, slight variation
    if is_fx:
        lots = round(float(rng.choice([0.05, 0.10, 0.10, 0.20, 0.25, 0.30, 0.50])), 2)
    else:
        lots = round(float(rng.choice([0.10, 0.20, 0.30, 0.50, 1.0])), 2)

    base_price = BASE_PRICE[symbol]

    # Stop distance behaviour: instrument-specific volatility regime,
    # plus some "too tight" stops to surface as an actionable finding later
    if is_fx:
        if symbol == "USDJPY":
            stop_pips = max(4, rng.normal(18, 9))
        else:
            stop_pips = max(3, rng.normal(14, 7))
        tp_pips = stop_pips * rng.uniform(0.8, 2.4)
        pip_size = 0.01 if symbol == "USDJPY" else 0.0001
        sl_dist_price = stop_pips * pip_size
        tp_dist_price = tp_pips * pip_size
    else:
        stop_pts = max(15, rng.normal(60, 30))
        tp_pts = stop_pts * rng.uniform(0.8, 2.2)
        sl_dist_price = stop_pts
        tp_dist_price = tp_pts

    open_price = base_price * (1 + rng.normal(0, 0.0006))

    if side == "buy":
        sl_price = open_price - sl_dist_price
        tp_price = open_price + tp_dist_price
    else:
        sl_price = open_price + sl_dist_price
        tp_price = open_price - tp_dist_price

    # Trade duration: skewed - lots of short scalps, some multi-hour swings
    duration_minutes = max(1, rng.lognormal(mean=3.4, sigma=1.3))
    close_time = open_time + timedelta(minutes=float(duration_minutes))

    # Outcome model: edge depends loosely on stop distance regime & time of day
    # (small synthetic "edge" structure so later analysis finds real patterns)
    hour = open_time.hour
    session_bonus = 0.05 if 12 <= hour <= 16 else (-0.03 if hour >= 22 or hour <= 2 else 0.0)
    tight_stop_penalty = -0.06 if (is_fx and stop_pips < 8) else 0.0
    win_prob = np.clip(0.46 + session_bonus + tight_stop_penalty, 0.15, 0.85)

    is_win = rng.random() < win_prob

    if is_win:
        close_price = tp_price if rng.random() < 0.7 else (
            open_price + (tp_dist_price * rng.uniform(0.2, 0.95)) * (1 if side == "buy" else -1)
        )
        comment = rng.choice(["tp", "[tp]", "manual close", "trailing stop", "expert close"])
    else:
        close_price = sl_price if rng.random() < 0.75 else (
            open_price - (sl_dist_price * rng.uniform(0.2, 0.95)) * (1 if side == "buy" else -1)
        )
        comment = rng.choice(["sl", "[sl]", "manual", "margin call"], p=[0.55, 0.25, 0.17, 0.03])

    # Profit calc
    if is_fx:
        pip_size = 0.01 if symbol == "USDJPY" else 0.0001
        price_diff = (close_price - open_price) if side == "buy" else (open_price - close_price)
        pips = price_diff / pip_size
        profit = pips * PIP_VALUE.get(symbol, 10) * lots
    else:
        price_diff = (close_price - open_price) if side == "buy" else (open_price - close_price)
        profit = price_diff * INDEX_POINT_VALUE[symbol] * lots

    commission = -round(0.7 * lots * (1 if is_fx else 1.5), 2)
    swap = round(rng.normal(-0.4, 1.2) * lots, 2) if duration_minutes > 240 else 0.0

    net_profit = round(profit + commission + swap, 2)

    rows.append({
        "ticket": 1000000 + i,
        "symbol": symbol,
        "type": side,
        "lots": lots,
        "open_time": open_time.strftime("%Y-%m-%d %H:%M:%S"),
        "close_time": close_time.strftime("%Y-%m-%d %H:%M:%S"),
        "open_price": round(open_price, 5 if is_fx else 2),
        "close_price": round(close_price, 5 if is_fx else 2),
        "sl": round(sl_price, 5 if is_fx else 2),
        "tp": round(tp_price, 5 if is_fx else 2),
        "commission": commission,
        "swap": swap,
        "profit": round(profit, 2),
        "net_profit": net_profit,
        "comment": comment,
    })

    current_time = close_time

df = pd.DataFrame(rows)
df.to_csv("/home/claude/project/data/raw_trade_history.csv", index=False)
print(f"Generated {len(df)} raw trades")
print(df.head(8).to_string())
print("\nNet profit sum:", df["net_profit"].sum().round(2))
print("Win rate (net_profit>0):", round((df.net_profit > 0).mean() * 100, 1), "%")
