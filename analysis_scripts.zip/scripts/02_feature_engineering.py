"""
02_feature_engineering.py
--------------------------
Takes the raw broker export and engineers derived features needed for
performance segmentation:

 1. trade_duration_min        - close_time - open_time, in minutes
 2. trade_duration_hours      - duration in hours (for bucketing)
 3. profit_per_lot            - net_profit / lots (normalizes size away)
 4. market_class              - 'forex' vs 'index' (parsed from symbol)
 5. closure_reason            - cleaned/standardised from free-text comment
 6. is_win                    - boolean outcome flag
 7. open_hour                 - hour of day trade was opened (0-23)
 8. session                   - Asian / London / NY / Overlap bucket
 9. day_of_week               - Mon-Fri
10. stop_distance_pips_or_pts - normalized distance from open to SL
11. risk_reward_planned       - planned TP distance / planned SL distance
12. cumulative_pnl            - running equity curve
13. rolling_drawdown          - running peak-to-trough drawdown
14. trade_sequence            - chronological trade index
"""

import re
import numpy as np
import pandas as pd

df = pd.read_csv("/home/claude/project/data/raw_trade_history.csv",
                  parse_dates=["open_time", "close_time"])

df = df.sort_values("open_time").reset_index(drop=True)
df["trade_sequence"] = np.arange(1, len(df) + 1)

# 1-2: duration ---------------------------------------------------------
df["trade_duration_min"] = (df["close_time"] - df["open_time"]).dt.total_seconds() / 60
df["trade_duration_hours"] = df["trade_duration_min"] / 60

# 3: profit per lot ------------------------------------------------------
df["profit_per_lot"] = (df["net_profit"] / df["lots"]).round(2)

# 4: market class ---------------------------------------------------------
INDEX_SYMBOLS = {"US30", "NAS100", "GER40", "SPX500"}
df["market_class"] = np.where(df["symbol"].isin(INDEX_SYMBOLS), "index", "forex")

# 5: closure reason extraction (messy text -> clean categories) ---------
def extract_closure_reason(comment: str) -> str:
    c = str(comment).strip().lower()
    c = re.sub(r"[\[\]]", "", c)  # strip brackets like "[sl]"
    if c in ("tp", "take profit"):
        return "take_profit"
    if c in ("sl", "stop loss"):
        return "stop_loss"
    if "trailing" in c:
        return "trailing_stop"
    if "expert" in c or "ea" in c:
        return "algo_logic_close"
    if "manual" in c:
        return "manual_close"
    if "margin" in c:
        return "margin_call"
    return "other"

df["closure_reason"] = df["comment"].apply(extract_closure_reason)

# 6: win flag -------------------------------------------------------------
df["is_win"] = df["net_profit"] > 0

# 7-9: time features -------------------------------------------------------
df["open_hour"] = df["open_time"].dt.hour
df["day_of_week"] = df["open_time"].dt.day_name()

def session_bucket(hour: int) -> str:
    if 0 <= hour < 7:
        return "Asian"
    if 7 <= hour < 12:
        return "London"
    if 12 <= hour < 17:
        return "London/NY Overlap"
    if 17 <= hour < 22:
        return "New York"
    return "Late NY / Asian Open"

df["session"] = df["open_hour"].apply(session_bucket)

# 10: stop distance (normalized) ------------------------------------------
def stop_distance(row):
    if row["type"] == "buy":
        return abs(row["open_price"] - row["sl"])
    return abs(row["sl"] - row["open_price"])

df["stop_distance_raw"] = df.apply(stop_distance, axis=1)

def to_pips_or_pts(row):
    if row["market_class"] == "forex":
        pip_size = 0.01 if row["symbol"] == "USDJPY" else 0.0001
        return row["stop_distance_raw"] / pip_size
    return row["stop_distance_raw"]

df["stop_distance_pips_or_pts"] = df.apply(to_pips_or_pts, axis=1).round(2)

# 11: planned risk:reward ---------------------------------------------------
def tp_distance(row):
    if row["type"] == "buy":
        return abs(row["tp"] - row["open_price"])
    return abs(row["open_price"] - row["tp"])

df["tp_distance_raw"] = df.apply(tp_distance, axis=1)
df["risk_reward_planned"] = (df["tp_distance_raw"] / df["stop_distance_raw"]).round(2)

# 12-13: equity curve & drawdown --------------------------------------------
df["cumulative_pnl"] = df["net_profit"].cumsum().round(2)
running_peak = df["cumulative_pnl"].cummax()
df["drawdown"] = (df["cumulative_pnl"] - running_peak).round(2)

# clean up helper columns
df = df.drop(columns=["stop_distance_raw", "tp_distance_raw"])

df.to_csv("/home/claude/project/data/trades_enriched.csv", index=False)

print(f"Engineered dataset: {df.shape[0]} trades x {df.shape[1]} columns")
print("\nNew/derived columns:")
derived = ["trade_sequence", "trade_duration_min", "trade_duration_hours", "profit_per_lot",
           "market_class", "closure_reason", "is_win", "open_hour", "day_of_week", "session",
           "stop_distance_pips_or_pts", "risk_reward_planned", "cumulative_pnl", "drawdown"]
print(derived)
print(f"\nTotal derived features: {len(derived)}")
print("\nClosure reason breakdown:")
print(df["closure_reason"].value_counts())
