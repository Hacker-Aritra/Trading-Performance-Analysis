"""
04_monte_carlo_simulation.py
------------------------------
Bootstrap Monte Carlo simulation: resamples (with replacement) from the
empirical distribution of the 92 historical net_profit outcomes to model
100 future trades, repeated 100,000 times. This produces a probability
distribution over future equity outcomes without assuming any parametric
return distribution (fat tails / skew in real trade P&L are preserved).
"""

import numpy as np
import pandas as pd
import json

rng = np.random.default_rng(7)

df = pd.read_csv("/home/claude/project/data/trades_enriched.csv")
historical_returns = df["net_profit"].values

N_SIMULATIONS = 100_000
N_FUTURE_TRADES = 100

# Vectorised bootstrap: sample N_SIMULATIONS x N_FUTURE_TRADES trade outcomes
sims = rng.choice(historical_returns, size=(N_SIMULATIONS, N_FUTURE_TRADES), replace=True)
cum_paths = np.cumsum(sims, axis=1)
final_pnl = cum_paths[:, -1]

# Path-level max drawdown for each simulated equity curve
running_peak = np.maximum.accumulate(cum_paths, axis=1)
drawdowns = cum_paths - running_peak
max_dd_per_path = drawdowns.min(axis=1)

# --- Summary statistics ---------------------------------------------------
percentiles = [1, 5, 10, 25, 50, 75, 90, 95, 99]
pnl_percentiles = {f"p{p}": round(float(np.percentile(final_pnl, p)), 2) for p in percentiles}

prob_profit = float((final_pnl > 0).mean())
prob_loss_more_than_500 = float((final_pnl < -500).mean())
prob_gain_more_than_1000 = float((final_pnl > 1000).mean())

worst_case_p5 = float(np.percentile(final_pnl, 5))
best_case_p95 = float(np.percentile(final_pnl, 95))
expected_value = float(final_pnl.mean())
median_value = float(np.median(final_pnl))
std_value = float(final_pnl.std())

dd_percentiles = {f"p{p}": round(float(np.percentile(max_dd_per_path, p)), 2) for p in [1, 5, 25, 50, 75, 95]}
median_max_dd = float(np.median(max_dd_per_path))
worst_dd_p5 = float(np.percentile(max_dd_per_path, 5))  # 5th pct of (negative) drawdowns = worse end of tail

results = {
    "n_simulations": N_SIMULATIONS,
    "n_future_trades": N_FUTURE_TRADES,
    "expected_pnl": round(expected_value, 2),
    "median_pnl": round(median_value, 2),
    "std_pnl": round(std_value, 2),
    "pnl_percentiles": pnl_percentiles,
    "probability_of_profit": round(prob_profit * 100, 1),
    "probability_loss_gt_500": round(prob_loss_more_than_500 * 100, 1),
    "probability_gain_gt_1000": round(prob_gain_more_than_1000 * 100, 1),
    "best_case_p95": round(best_case_p95, 2),
    "worst_case_p5": round(worst_case_p5, 2),
    "drawdown_percentiles": dd_percentiles,
    "median_max_drawdown": round(median_max_dd, 2),
    "worst_case_p5_drawdown": round(worst_dd_p5, 2),
}

with open("/home/claude/project/data/monte_carlo_results.json", "w") as f:
    json.dump(results, f, indent=2)

# Save a sample of paths (for charting) - not all 100k, just 300 for visual + full final_pnl array for histogram
np.save("/home/claude/project/data/mc_sample_paths.npy", cum_paths[:300])
np.save("/home/claude/project/data/mc_final_pnl.npy", final_pnl)
np.save("/home/claude/project/data/mc_max_dd.npy", max_dd_per_path)

print(f"Monte Carlo: {N_SIMULATIONS:,} simulations x {N_FUTURE_TRADES} future trades")
print(json.dumps(results, indent=2))
